<template>
    <div>
      <h1>users {{title}}</h1>
    </div>
  </template>
  
  <script>
  export default {
    name:"UsersApp",
   data(){
    return{
      title : "Title"
    }
   }
  }
  </script>
  
  <style scoped>
  
  </style>