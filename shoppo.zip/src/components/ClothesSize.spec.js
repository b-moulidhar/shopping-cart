const clothes = require('./ClothesSize.vue')
// const CartComp = require('./CartComp.vue')
// const vtl= require('@testing-library/vue')
import { fireEvent, render,screen} from '@testing-library/vue'
import '@testing-library/jest-dom'
import '@vue/test-utils'

it('has input',async()=>{
    const {container}=render(clothes);
    const input = container.querySelector('h2')
    expect(input).toBeInTheDocument()
})